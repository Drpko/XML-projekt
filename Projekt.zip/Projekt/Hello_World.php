<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="Author" content="Tin Dobrenic">
        <meta name="JMBAG" content="0035217088">
        <link rel="stylesheet" href="styles.css">
        <title>XML projekt</title>
    </head>
    <body>
        <main>
            <img class="right" src="images/plant-right.png">
            <div class="L_intro">
                <h1>We Are Humaaan After All</h1>
                <p>
                    Fitts's law is a predictive model of human movement primarily used in human–computer interaction
                    and ergonomics.
                </p>
                <div>
                    <div>I'm Humaaan</div>
                    <div>Or am I?</div>
                </div>
            </div>
            <div class="clear"></div>
            <div class="help"></div>
            <div class="mid">
                <h1>Uncanny Valley</h1>
                <p class="mid">An empirically estimated uncanny valley for<br> static robot face images In aesthetics.</p>
            </div>
            <div class="clear"></div>
            <div class="hard">
                <img src="images/image2.png" alt="">
                <img src="images/image1.png" alt="">
                <img src="images/image3.png" alt="">
                <div class="prvi">
                    <h2>Tani genshō</h2>
                    <p>
                        Examples can be found in robotics, 3D computer animations, and lifelike dolls among others.
                    </p>
                </div>
                <div class="drugi">
                    <h2>Mori's hypothesis</h2>
                    <p>
                        An empirically estimated uncanny valley for static robot face images In aesthetics.<a href="#">This is a link</a>
                    </p>
                </div>
                <div class="treci">
                    <h2>Robot Repliee</h2>
                    <p>
                        The concept was identified by the robotics professor Masahiro Mori as bukimi no tani genshō
                    </p>
                </div>
            </div>
            <div class="clear"></div>
            <div class="help2"></div>
            <h1 id="hard2">Riješi rebus</h1>
            <div class="clear"></div>
            <p style="margin: 0 340px 0">stisni na sliku za novi rebus</p>
            <div class="help3"></div>
            <img style="margin: 25px 100px 0;" src="images/rebus.png" alt="" id="rebus" onclick="changeImage()">
            <form action="" method="post">
                <div class="rjesenje">                    
                    <input id="rjesenje" name="rjesenje" type="text">
                    <input class="sub"  name="odgovor" type="submit" value=" Odgovori ">
                </div> 
            </form><br>


<?php

$rjesenje="";


if ($_SERVER["REQUEST_METHOD"] == "POST") {
	
	$ans=$_POST;

	if (empty($ans["rjesenje"]))  {
        	echo "Niste upisali riješenje!";
		
    		}
	else {
		$rjesenje= $ans["rjesenje"];
	
		provjera($rjesenje);
	}
}


function provjera($rjesenje) {
	

	$xml=simplexml_load_file("Rjesenje.xml");
	
	
	foreach ($xml->Rjesenje as $rjes) {
  	 	$rj = $rjes->Tocno;
        if($rj == $rjesenje){
			echo "TOČAN ODGOVOR!";
			return;
		}
        
    }
    echo "Netočan odgovor :(";
        return;
    
}
?>



            <div class="clear"></div>  
        </main>
        <footer>
            <hr>    
            <div class="footerR">
            <p>
                <b>Tin Dobrenić<br>
                0035217088</b>
            </p>
            </div>
        </footer>
    </body>
</html>


<script type="text/javascript">
    var image = document.getElementById("rebus");
    function changeImage() {
    if (image.getAttribute('src') == "images/rebus.png"){
        image.src = "images/rebus1.png";
    } else if (image.getAttribute('src') == "images/rebus1.png"){
        image.src = "images/rebus2.png";
    } else {
        image.src = "images/rebus.png";

    }
}
</script>